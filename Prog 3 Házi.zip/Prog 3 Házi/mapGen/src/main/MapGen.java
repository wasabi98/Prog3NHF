package main;

import java.awt.GridLayout;

import javax.swing.JPanel;
import javax.swing.JTextField;

public class MapGen extends JPanel {
	JTextField[][] fields;
	int row;
	int column;
	
	
	MapGen(int row, int column)
	{
		super();
		fields = new JTextField[row][column];
		setLayout(new GridLayout(row, column,1,1));
		for(int i = 0; i < row; i++)
		{
			for(int j = 0; j < column; j++)
			{
				fields[i][j] = new JTextField("",1);
				add(fields[i][j]);
			}
		}
	}
}
//new GridLayout(row, column, 1,1)