package main;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import javax.swing.JButton;
import javax.swing.JFrame;


public class Main {

	static JFrame frame;
	static MapGen mg;
	static int row;
	static int column;
	static JButton button;
	static int[][] out;
	
	public static void main(String[] args) throws ClassNotFoundException, IOException {
		frame = new JFrame();
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		row = 15; // ._. sorry
		column = 15;
		
		mg = new MapGen(row, column);
		out = new int[row][column];
		button = new JButton("Create");
		button.addActionListener(new ActionListener()
				{
					@Override
					public void actionPerformed(ActionEvent a) {
						for(int i = 0; i < row; i++)
						{
							for(int j = 0; j < column; j++)
							{
								if(mg.fields[i][j].getText().equals(""))
									out[i][j] = -1;
								else
									out[i][j] = Integer.parseInt(mg.fields[i][j].getText());
							}
						}
						
						FileOutputStream file;
						ObjectOutputStream outs;
						try {
							file = new FileOutputStream("test.txt");
							outs = new ObjectOutputStream(file);
							
							outs.writeObject(out);
							
							outs.close();
							file.close();
						} catch (IOException e1) {
							
							e1.printStackTrace();
						} 
						
			            
					}
					
		            
		            
		            
				});
		
		frame.add(mg, BorderLayout.NORTH);
		frame.add(button, BorderLayout.SOUTH);
		frame.pack();
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
	}

}
