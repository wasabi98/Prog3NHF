package main;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.io.IOException;

import javax.swing.JTextField;

import org.junit.Assert;
import org.junit.Test;


public class NurikabeTest {
	

	
	@Test
	public void TileTest() {
		Tile tile1 = new Tile(1, false); 
		Assert.assertEquals(tile1.isEnabled(), false);//be�ll�tja-e hogy a 0 < sz�mok nem megnyomhat� Tile-on vannak
		
		Tile tile2 = new Tile(0, true);
		Assert.assertNotEquals(tile2.getImage(), null);//megn�zi hogy a marked mez�k t�nyleg megkapj�k az image-et
		
		Tile tile3 = new Tile(-1, false);
		Assert.assertEquals(tile3.getBackground(), Color.BLACK);
		
		
	}
	@Test
	public void ActionListener()
	{
		Tile tile1 = new Tile(0, false);
		Assert.assertEquals(tile1.getBackground(), Color.WHITE);
		ButtonMouseListener bml = new ButtonMouseListener();
		bml.mousePressed(new MouseEvent(tile1, MouseEvent.MOUSE_CLICKED, 100, 0, 0, 0, 1, false, MouseEvent.BUTTON1));
		Assert.assertEquals(tile1.getBackground(), Color.BLACK);
		Assert.assertEquals(tile1.getValue(), -1);

	}
	@Test
	public void CheckMapRight() throws ClassNotFoundException, IOException
	{
		Map map = new Map(new int[][]{{1,-1},{-1,-1}}, new int[][]{{1,-1},{-1,-1}});
		/* 1  -1
		 *-1  -1
		 */
		JTextField textfield = new JTextField();
		Game game = new Game(map);
		ActionListener al = new ActionListener() //val�s k�dban l�v� anon�m actionListener
		{
			
			
			@Override
			public void actionPerformed(ActionEvent e) {
				boolean isCorrect = true;
				for(int i = 0; i < map.getCorrect().length; i++)
				{
					for(int j = 0; j < map.getCorrect()[0].length; j++)
					{
						int correct = map.getCorrect()[i][j];
						int guess = map.getList().get(i).get(j).getValue();
						if(correct != guess)
							isCorrect = false;
					}
				}
				if(isCorrect)
					textfield.setText("j� :D");
				else
					textfield.setText("rossz :(");
			}
			
		};
		game.getCheckButton().addActionListener(al);
		al.actionPerformed(new ActionEvent(game.getCheckButton(), MouseEvent.MOUSE_CLICKED, ""));
		Assert.assertEquals(textfield.getText(), "j� :D");
	}
	@Test
	public void CheckMapWrong() throws ClassNotFoundException, IOException
	{
		Map map = new Map(new int[][]{{1,-1},{-1,-1}}, new int[][]{{1,0},{-1,-1}});
		/* 1  -1													  |
		 *-1  -1													  V
		 															  itt  0 van */
		JTextField textfield = new JTextField();
		Game game = new Game(map);
		ActionListener al = new ActionListener() //val�s k�dban l�v� anon�m actionListener
		{
			
			
			@Override
			public void actionPerformed(ActionEvent e) {
				boolean isCorrect = true;
				for(int i = 0; i < map.getCorrect().length; i++)
				{
					for(int j = 0; j < map.getCorrect()[0].length; j++)
					{
						int correct = map.getCorrect()[i][j];
						int guess = map.getList().get(i).get(j).getValue();
						if(correct != guess)
							isCorrect = false;
					}
				}
				if(isCorrect)
					textfield.setText("j� :D");
				else
					textfield.setText("rossz :(");
			}
			
		};
		game.getCheckButton().addActionListener(al);
		al.actionPerformed(new ActionEvent(game.getCheckButton(), MouseEvent.MOUSE_CLICKED, ""));
		Assert.assertEquals(textfield.getText(), "rossz :(");
	}
	

}
