package main;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.Border;

public class Options extends JFrame{
	
	private JScrollPane scrollpane;
	private JList<String> list;
	private JButton button;
	private JPanel panel;
	
	
	Options()
	{
		super("Nurikabe");
		String[] maps = {"palya_1_1", "palya_1_2", "palya_1_3", "palya_1_4", "palya_1_5", "palya_2_1", "palya_2_2", "palya_2_3", "palya_3_1"};
		list = new JList<String>(maps);
		scrollpane = new JScrollPane(list);
		scrollpane.setPreferredSize(new Dimension(300, 300));
		panel = new JPanel();
		Border border = BorderFactory.createTitledBorder("P�lyav�laszt�s");
		panel.setBorder(border);
		panel.add(scrollpane);
		
		button = new JButton("Kezd�s");
		button.setPreferredSize(new Dimension(200, 50));

		this.add(button, BorderLayout.SOUTH);
		this.add(Box.createRigidArea(new Dimension(0, 10))); 
		this.add(panel, BorderLayout.NORTH);
		
		this.setBounds(20, 20, 20, 20);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.pack();
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setVisible(true);
		
	}
	JButton getButton()
	{
		return button;
	}
	JList<String> getList()
	{
		return list;
	}
	 
}
