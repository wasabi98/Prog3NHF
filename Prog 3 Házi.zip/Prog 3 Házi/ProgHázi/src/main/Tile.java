package main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import main.ButtonMouseListener;

public class Tile extends JButton{
	
	private BufferedImage image;
	private int value; // 0 == nincs megjel�lve/sima , >0 == sz�m, -1 == tenger
	private boolean marked; // true p�tty, false nem p�tty
	//boolean clickable;
	
	
	
	public Tile(int value, boolean marked)
	{
		super();
		this.value = value;
		this.marked = marked;
		this.setBackground(Color.WHITE);
		
		
		setPreferredSize(new Dimension(30, 30));
		
		image = new BufferedImage(5,5, BufferedImage.TYPE_INT_RGB);
		Graphics2D g = image.createGraphics();
		g.setPaint(Color.BLACK);
		g.fillRect(0, 0, image.getWidth(), image.getHeight());
		
		if(value > 0)
		{
			setEnabled(false);
			setText(Integer.toString(value));
		}
		else if(value == 0)
		{
			setEnabled(true);
			setIcon(null);
			this.marked = false;
			this.value = 0;
		}
		else if(value == -1)
		{
			setEnabled(true);
			setIcon(null);
			setBackground(Color.BLACK);
			this.marked = false;
			this.value = -1;
		}
		if(marked)
		{
			setEnabled(true);
			setIcon(new ImageIcon(image));
			this.marked = true;
			this.value = 0;
		}
			
		
		setBorderPainted(false);
		setFocusable(false);
		setBorder(null);

	    this.addMouseListener(new ButtonMouseListener());
	    
	    
		
	}
	int getValue()
	{
		return value;
	}
	boolean getMarked()
	{
		return marked;
	}
	void setValue(int v)
	{
		value = v;
	}
	void setMarked(boolean m)
	{
		marked = m;
	}
	BufferedImage getImage()
	{
		return image;
	}

	
}
