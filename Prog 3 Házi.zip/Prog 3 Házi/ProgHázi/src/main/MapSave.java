package main;

import java.io.Serializable;

public class MapSave implements Serializable{
	 private int[][] correct, guess;
	MapSave(int[][] correct)
	{
		this.correct = correct;
		guess = new int[correct.length][correct[0].length];
	}
	int[][] getCorrect()
	{
		return correct;
	}
	int[][] getGuess()
	{
		return guess;
	}
	

}
