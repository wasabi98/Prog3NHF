package main;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class Main {
	
	private static Menu menu;
	private static Help help;
	private static Options options;
	private static Game game;
	private static MapSave mapSave;
	
	public static void main(String[] args) {
		menu = new Menu();
		menu.getExitButton().addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent a)
			{
				menu.dispose();
			}
		}
		);
		menu.getHelp().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent a) {
				help = new Help();
				
			}
			
		});
		Menu.getNewGameButton().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent a) {
				options = new Options();
				options.getButton().addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						FileInputStream file = null;
						try {
							file = new FileInputStream(options.getList().getSelectedValue() + ".txt");
						} catch (FileNotFoundException e1) {
							
							e1.printStackTrace();
						} 
						ObjectInputStream in = null;
			            try {
							in = new ObjectInputStream(file);
						} catch (IOException e1) {
							e1.printStackTrace();
						} 
						
						
						try {
							game = new Game(new Map((int[][]) in.readObject()));
						} catch (ClassNotFoundException | IOException e1) {
							e1.printStackTrace();
						}
						
					}
					
				});
			}
			
		});
		
		Menu.getLoadButton().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				FileInputStream file = null;
				try {
					file = new FileInputStream("save.txt");
				} catch (FileNotFoundException e1) {
					
					e1.printStackTrace();
				} 
				ObjectInputStream in = null;
	            try {
					in = new ObjectInputStream(file);
				} catch (IOException e1) {
					e1.printStackTrace();
				} 
				
				
				try {
					mapSave = (MapSave) in.readObject();
					game = new Game(new Map(mapSave.getCorrect(), mapSave.getGuess()));
				} catch (ClassNotFoundException | IOException e1) {
					e1.printStackTrace();
				}
				
			}
			
		});
		
	}

}
