package main;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.SwingUtilities;

class ButtonMouseListener extends MouseAdapter
{
	
	public void mousePressed(MouseEvent e){
		Tile button = (Tile) e.getSource();
		if(SwingUtilities.isRightMouseButton(e) && button.isEnabled())
		{
			
			button.setBackground(Color.WHITE);
			if(button.getIcon()==null)
			{
				button.setIcon(new ImageIcon(button.getImage()));
				button.setMarked(true);
				button.setValue(0);					
			}
				
			else
			{
				button.setIcon(null);
				button.setMarked(false);
				button.setValue(0);
			}
				
			
			
		}
		else if(SwingUtilities.isLeftMouseButton(e)  && button.isEnabled())
		{
			button.setIcon(null);
			if(button.getBackground() == Color.BLACK)
			{
				button.setBackground(Color.WHITE);
				button.setValue(0);
			}
				
			else
			{
				button.setBackground(Color.BLACK);
				button.setValue(-1);
			}
				
			
			
		}
       
	}
}