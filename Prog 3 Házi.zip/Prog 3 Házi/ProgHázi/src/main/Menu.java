package main;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;


public class Menu extends JFrame{
	
	
	
	private static JPanel panel;
	private static JButton newGameButton;
	private static JButton loadButton;
	private JButton exitButton;
	private JMenuBar menuBar;
	private JMenu menu;
	private JMenuItem help;
	Menu() {
		super("Nurikabe");
		
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		panel = new JPanel();
		BoxLayout boxlayout = new BoxLayout(panel, BoxLayout.Y_AXIS);
		panel.setLayout(boxlayout);
		
		panel.setBorder(new EmptyBorder(new Insets(20, 30, 20, 30)));
		 
		 
		
		newGameButton = new JButton("�j j�t�k");
		//newGameButton.setPreferredSize(new Dimension(200, 50));
		loadButton = new JButton("Bet�lt�s");
		//loadButton.setPreferredSize(new Dimension(200, 50));
		exitButton = new JButton("Kil�p�s");
		//exitButton.setPreferredSize(new Dimension(200, 50));
		
		JPanel newGameButtonPanel = new JPanel(new BorderLayout());
		JPanel loadButtonPanel = new JPanel(new BorderLayout());		
		JPanel exitButtonPanel = new JPanel(new BorderLayout());
		
		newGameButtonPanel.add(newGameButton);
		loadButtonPanel.add(loadButton);
		exitButtonPanel.add(exitButton);
		
		newGameButtonPanel.setPreferredSize(new Dimension(200, 50));
		loadButtonPanel.setPreferredSize(new Dimension(200, 50));
		exitButtonPanel.setPreferredSize(new Dimension(200, 50));
		
		menuBar = new JMenuBar();
		menu = new JMenu("Men�");
		help = new JMenuItem("S�g�");
		
		menu.add(help);
		menuBar.add(menu);
		
		
		panel.add(newGameButtonPanel);
		panel.add(Box.createRigidArea(new Dimension(0, 10))); 
		panel.add(loadButtonPanel);
		panel.add(Box.createRigidArea(new Dimension(0, 10))); 
		panel.add(exitButtonPanel);
		
	    this.setJMenuBar(menuBar);
		this.add(panel);
		this.pack();
		this.setLocationRelativeTo(null);
		this.setResizable(false);
	}
	static JButton getNewGameButton() {
		return newGameButton;
	}
	static JButton getLoadButton() {
		return loadButton;
	}
	JButton getExitButton() {
		return exitButton;
	}
	JMenuItem getHelp() {
		return help;
	}

}
