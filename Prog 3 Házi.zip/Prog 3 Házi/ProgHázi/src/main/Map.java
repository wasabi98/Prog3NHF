package main;

import java.awt.GridLayout;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;

import main.Tile;

public class Map extends JPanel{
	
	private List<List<Tile>> list = new ArrayList<List<Tile>>();
	private int[][] correct;
	private int row;
	private int column;
	
	
	Map(int[][] correct) throws IOException, ClassNotFoundException
	{
		super();
		this.correct = correct;
		row = correct.length;
		column = correct[0].length;
		this.setLayout(new GridLayout(row,column,1,1));
		
		for(int i = 0; i < row; i++)
		{
			
			List<Tile> tmp = new ArrayList<Tile>(column);
			
			for(int j = 0;j < column; j++)
			{
				int tmp_;
				if(correct[i][j] == -1)
					tmp_ = 0;
				else
					tmp_ = correct[i][j];
				
				Tile tile = new Tile(tmp_, false);
				/*tile.addMouseListener(new MouseAdapter()
				{
					
					public void mousePressed(MouseEvent e){
						JButton button = (JButton) e.getSource();
						if(SwingUtilities.isRightMouseButton(e) && button.isEnabled())
						{
							
							button.setBackground(Color.WHITE);
							if(button.getIcon()==null)
							{
								button.setIcon(new ImageIcon(tile.image));
								tile.marked = true;
								tile.value = 0;
							}
								
							else
							{
								button.setIcon(null);
								tile.marked = false;
								tile.value = 0;
							}
								
							
							
						}
						else if(SwingUtilities.isLeftMouseButton(e) && button.isEnabled())
						{
							button.setBackground(Color.BLACK);
							tile.value = -1;
						}
				       
					}
				});*/
				tmp.add(tile);				
				
			}
			list.add(tmp);
		}
		for(int i = 0; i < row; i++)
		{
			for(int j = 0;j < column; j++)
			{
				this.add(list.get(i).get(j));
			}
		}
	}
	
	Map(int[][] correct, int[][] guess) throws IOException, ClassNotFoundException
	{
		super();
		this.correct = correct;
		row = correct.length;
		column = correct[0].length;
		this.setLayout(new GridLayout(row,column,1,1));
		
		for(int i = 0; i < row; i++)
		{
			
			List<Tile> tmp = new ArrayList<Tile>(column);
			
			for(int j = 0;j < column; j++)
			{
				Tile tile;
				if(guess[i][j] == -1)
					tile = new Tile(-1, false);
				else if(guess[i][j] == -2)
				{
					tile = new Tile(0, true);
				}
				else if(guess[i][j] == 0)
				{
					tile = new Tile(0, false);
				}
				else
				{
					tile = new Tile(guess[i][j], false);
				}
				
			
				tmp.add(tile);				
				
			}
			list.add(tmp);
		}
		for(int i = 0; i < row; i++)
		{
			for(int j = 0;j < column; j++)
			{
				this.add(list.get(i).get(j));
			}
		}
	}
	int[][] getCorrect()
	{
		return correct;
	}
	List<List<Tile>> getList()
	{
		return list;
	}
}
