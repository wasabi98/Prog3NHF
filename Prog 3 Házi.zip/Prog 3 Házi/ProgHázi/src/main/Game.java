package main;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import javax.swing.*;

public class Game extends JFrame{
	private JMenuBar menuBar;
	private JMenu menu;
	private JMenuItem save;
	private Map map;
	private JButton checkButton;
	private JTextField textfield;
	private MapSave mapSave;
	
	Game(Map map_)
	{
		super("Nurikabe");
		menuBar = new JMenuBar();
		menu = new JMenu("F�jl");
		save = new JMenuItem("Ment�s");
		
		menu.add(save);
		menuBar.add(menu);
		
		map = map_;
		
		//this.add(map, BorderLayout.NORTH);
		
		
		checkButton = new JButton("Ellen�rz�s");
		textfield = new JTextField("");
		textfield.setEditable(false);
		textfield.setHorizontalAlignment(JTextField.CENTER);

		
		checkButton.addActionListener(new ActionListener()
		{
			
			
			@Override
			public void actionPerformed(ActionEvent e) {
				boolean isCorrect = true;
				for(int i = 0; i < map.getCorrect().length; i++)
				{
					for(int j = 0; j < map.getCorrect()[0].length; j++)
					{
						int correct = map.getCorrect()[i][j];
						int guess = map.getList().get(i).get(j).getValue();
						if(correct != guess)
							isCorrect = false;
					}
				}
				if(isCorrect)
					textfield.setText("j� :D");
				else
					textfield.setText("rossz :(");
			}
			
		});
		
		
		save.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent a) {
				
				FileOutputStream file;
				ObjectOutputStream outs;
				mapSave = new MapSave(map.getCorrect());
				for(int i = 0; i < map.getCorrect().length; i++)
				{
					for(int j = 0 ;j < map.getCorrect()[0].length; j++)
					{
						if(map.getList().get(i).get(j).getValue() == 0)
						{
							if(map.getList().get(i).get(j).getMarked())
							{
								mapSave.getGuess()[i][j] = -2;
							}
							else
							{
								mapSave.getGuess()[i][j] = 0;
							}
						}
						else if(map.getList().get(i).get(j).getValue() == -1)
						{
							mapSave.getGuess()[i][j] = -1;
						}
						else
						{
							mapSave.getGuess()[i][j] = map.getList().get(i).get(j).getValue();
						}
					}
				}
				
				try {
					file = new FileOutputStream("save.txt");
					outs = new ObjectOutputStream(file);
					
					outs.writeObject(mapSave);
					
					outs.close();
					file.close();
				} catch (IOException e1) {
					
					e1.printStackTrace();
				} 
				textfield.setText("Elmentve");
	            
			}
			
            
            
            
		});
		setJMenuBar(menuBar);
		add(map, BorderLayout.NORTH);
		add(checkButton, BorderLayout.SOUTH);
		add(textfield);
		pack();
		setVisible(true);
		setLocationRelativeTo(null);
		setResizable(false);
	}
	JButton getCheckButton()
	{
		return checkButton;
	}
	JTextField getTextField()
	{
		return textfield;
	}
}
