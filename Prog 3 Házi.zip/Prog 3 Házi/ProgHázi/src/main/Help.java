package main;

import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Help {
	private JFrame frame;
	private ImageIcon icon;
	private JLabel label;
	Help()
	{
			icon = new ImageIcon("help.png");
	 		frame = new JFrame("Sug�");
		    frame.setLayout(new FlowLayout());
		    label = new JLabel();
		    label.setIcon(icon);
		    
		    frame.add(label);
		    frame.pack();
		    frame.setVisible(true);
		    frame.setResizable(false);
		    frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
}
